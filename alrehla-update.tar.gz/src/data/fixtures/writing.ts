/**
 * بيانات تجريبية للتطوير المحلي فقط — لا تُستخدم في الموقع المنشور.
 *
 * Development-only sample data. Nothing here is real, and nothing here is
 * exported to pages: the read functions in `src/data/domains` fall back to it
 * only when NODE_ENV is 'development'.
 */

import {
  WritingPackage, Instructor, PersonalizedProduct, AddonProduct, SubscriptionTier, 
  Testimonial, CreativeService, BlogPost, UserProfile, Booking, SessionWithDetails, Order, 
  Publisher, InstructorPayout, PublisherPayout, SessionMessage, SessionAttachment, 
  StudyMaterial, InstructorStudent, BoxSubscription, SupportTicket, 
  JoinRequest, SupportSessionRequest, AuditLog, ServiceOrder, CourseSubscription, 
  SupportTicketMessage, FamilyMember, NotificationItem, UserRole,
  PublisherOrder,
  InstructorPricingOption, PricingFormulaSettings, InstructorCompensationProfile, InstructorCertification
} from '@/types';

export const mockWritingPackages: WritingPackage[] = [
  // مسار الإبداع التأسيسي (دون 12 سنة)
  {
    id: 'pkg-1',
    slug: 'golden-words',
    name: 'الكلمات الذهبية',
    ageGroup: 'under_12',
    price: 2990,
    durationText: '3 أشهر',
    sessionsCount: 12,
    sessionDuration: '40 دقيقة',
    targetAudience:
      'تناسب الطفل الذي يخوض تجربة منظمة أولى مع الكتابة، أو يريد اكتشاف علاقته بها في مساحة فردية دافئة وخفيفة، دون الحاجة إلى خبرة سابقة.',
    prerequisiteNote:
      'مستقلة بذاتها (يمكن الانتقال بعدها إلى السطور السحرية لكنها ليست شرطًا لها)',
    shortDescription: 'رحلة استكشافية قصيرة للمبتدئين.',
    fullDescription: 'دورة تركز على اكتشاف الكتابة كمساحة للتعبير...',
    isActive: true,
  },
  {
    id: 'pkg-2',
    slug: 'magic-lines',
    name: 'السطور السحرية',
    ageGroup: 'under_12',
    price: 5990,
    durationText: '6 أشهر',
    sessionsCount: 24,
    targetAudience:
      'تناسب الطفل الذي يريد مساحة أطول للكتابة والتجريب، ويرغب في توسيع أدواته واكتشاف أنواع متعددة من الكتابة والعمل على مشروع كتابي خاص يمتد عبر فترة أطول.',
    prerequisiteNote: 'لا تشترط إتمام الكلمات الذهبية مسبقًا',
    shortDescription: 'رحلة أطول لتوسيع أدوات الكتابة وبناء مشروع.',
    fullDescription: 'دورة لتوسيع مهارات الكتابة وبناء مشروع شخصي...',
    isActive: true,
  },
  // مسار اليافعين والكبار (12 سنة فأعلى)
  {
    id: 'pkg-3',
    slug: 'first-spark',
    name: 'الشرارة الأولى',
    ageGroup: '12_plus',
    price: 2990,
    durationText: '3 أشهر',
    sessionsCount: 12,
    sessionDuration: '40 دقيقة',
    targetAudience:
      'تناسب اليافع أو الشاب أو الكبير الذي يريد أن يبدأ ممارسة الكتابة، أو يكتشف علاقته بها، أو يحوّل أفكاره الأولى إلى نصوص فعلية، دون الحاجة إلى الاشتراك في مسار طويل.',
    prerequisiteNote: 'مستقلة بذاتها',
    shortDescription: 'رحلة قصيرة لتحويل الأفكار إلى نصوص.',
    fullDescription: 'الخطوة الأولى في عالم الكتابة والتعبير...',
    isActive: true,
  },
  {
    id: 'pkg-4',
    slug: 'crafting-impact',
    name: 'صياغة الأثر',
    ageGroup: '12_plus',
    price: 5990,
    durationText: '6 أشهر',
    sessionsCount: 24,
    targetAudience:
      'تناسب من يريد أن يمنح الكتابة وقتًا أطول، ويعمّق أدواته، ويجرب أكبر من نوع أدبي، ثم ينتقل إلى بناء مشروع كتابي خاص به.',
    prerequisiteNote: 'مستقلة بذاتها، ويمكن الاشتراك فيها مباشرة',
    shortDescription: 'مسار متعمق لتجربة أنواع أدبية مختلفة.',
    fullDescription: 'برنامج متكامل يعمق أدوات الكاتب ويوسع مداركه...',
    isActive: true,
  },
  {
    id: 'pkg-5',
    slug: 'story-maker',
    name: 'صانع الحكاية',
    ageGroup: '12_plus',
    price: 11990,
    durationText: '6 أشهر',
    sessionsCount: 24,
    targetAudience:
      'تناسب المشارك الذي أتم «صياغة الأثر» وأصبح لديه أساس كتابي ومشروع يمكن تطويره، ويريد التعمق في بناء الحكاية والعمل على مشروع أدبي أكبر امتدادًا.',
    prerequisiteNote: 'يشترط إتمام رحلة صياغة الأثر أولًا',
    prerequisitePackageId: 'pkg-4',
    shortDescription: 'رحلة لبناء وتطوير مشروع أدبي متكامل.',
    fullDescription:
      'التعمق في بناء الحكاية والشخصيات وتطوير مشروع أدبي متماسك...',
    isActive: true,
  },
  {
    id: 'pkg-6',
    slug: 'journey-to-story',
    name: 'رحلتي نحو الحكاية',
    ageGroup: '12_plus',
    price: 19190,
    durationText: '12 شهر (البرنامج الكامل)',
    sessionsCount: 48,
    targetAudience:
      'تناسب من يريد خوض مسار سنوي واحد متصل بدلًا من رحلتين منفصلتين، ويبحث عن تجربة متصلة تمنحه الوقت للانتقال من التأسيس والتجريب إلى بناء المشروع ثم صقله وتطوير ملف أعماله.',
    prerequisiteNote:
      'لا تشترط إتمام أي رحلة سابقة، لأنها تحتوي المسار الكامل داخل تجربة سنوية واحدة',
    shortDescription: 'المسار الكامل من التجريب إلى صقل مشروع التخرج.',
    fullDescription:
      'برنامج سنوي شامل ينتقل بالكاتب من نقطة البداية وحتى إنهاء مشروعه...',
    isActive: true,
  },
];

export const mockInstructors: Instructor[] = [
  {
    id: 'inst-1',
    status: 'active',
    userId: 'user-101',
    displayName: 'سارة أحمد',
    bio: 'مدربة معتمدة بخبرة واسعة في تنمية مهارات الكتابة الإبداعية لدى الأطفال.',
    specialties: ['كتابة إبداعية', 'الخيال العلمي'],
    yearsExperience: 5,
    isSample: true,
    trainingPassed: true,
    workModel: 'per_session',
    requestedPrice: 150,
    approvedPrice: 150,
    weeklySchedule: [
      { day: 'saturday', time: '10:00', isBooked: true },
      { day: 'saturday', time: '12:00' },
      { day: 'monday', time: '16:00' }
    ]
  },
  {
    id: 'inst-2',
    status: 'active',
    userId: 'user-102',
    displayName: 'خالد عبد الله',
    bio: 'كاتب متخصص في أدب الطفل وحائز على عدة جوائز محلية.',
    specialties: ['الكتابة للأطفال', 'بناء الشخصيات'],
    yearsExperience: 7,
    isSample: true,
    trainingPassed: true,
    workModel: 'monthly',
    monthlyHoursCommitted: 60,
    requestedPrice: 120,
    approvedPrice: 120,
    weeklySchedule: [
      { day: 'sunday', time: '14:00' },
      { day: 'tuesday', time: '14:00' },
      { day: 'thursday', time: '14:00' }
    ]
  },
  {
    id: 'inst-pending',
    userId: 'user-new',
    displayName: 'محمود طارق',
    bio: 'مدرب شغوف بتعليم أساسيات السرد القصصي.',
    specialties: ['كتابة الخيال'],
    yearsExperience: 2,
    status: 'pending_approval',
    trainingPassed: true,
    workModel: 'per_session',
    requestedPrice: 200, // Wants a higher price
    weeklySchedule: [
      { day: 'wednesday', time: '18:00' }
    ]
  },
  {
    id: 'inst-training',
    userId: 'user-training',
    displayName: 'منى سعيد',
    bio: 'كاتبة شابة تسعى للانضمام للمنصة.',
    specialties: ['الشعر'],
    yearsExperience: 1,
    status: 'pending_training',
    trainingPassed: false,
    workModel: 'monthly',
    monthlyHoursCommitted: 80,
    requestedPrice: 100,
    weeklySchedule: []
  }
];

export const mockSessions: SessionWithDetails[] = [
  {
    id: 'sess-1',
    courseSubscriptionId: 'csub-1',
    sessionNumber: 1,
    userId: 'student-1',
    participantType: 'self',
    packageId: 'pkg-1',
    instructorId: 'inst-1',
    status: 'confirmed',
    scheduledAt: new Date(Date.now() + 86400000 * 2).toISOString(),
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'sess-2',
    courseSubscriptionId: 'csub-2',
    sessionNumber: 1,
    userId: 'current-user',
    participantType: 'child',
    childId: 'dep-child-2',
    packageId: 'pkg-2',
    instructorId: 'inst-2',
    status: 'completed',
    scheduledAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    createdAt: new Date(Date.now() - 86400000 * 10).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'sess-3',
    courseSubscriptionId: 'csub-3',
    sessionNumber: 1,
    userId: 'student-3',
    participantType: 'self',
    packageId: 'pkg-1',
    instructorId: 'inst-1',
    status: 'pending',
    scheduledAt: new Date(Date.now() + 86400000 * 5).toISOString(),
    createdAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const mockServiceOrders: ServiceOrder[] = [
  {
    id: 'so-1',
    buyerProfileId: 'parent-1',
    packageId: 'pkg-1',
    status: 'paid',
    amount: 1500,
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
  },
  {
    id: 'so-2',
    buyerProfileId: 'parent-2',
    packageId: 'pkg-2',
    status: 'pending',
    amount: 800,
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  }
];

export const mockCourseSubscriptions: CourseSubscription[] = [
  {
    id: 'csub-1',
    packageId: 'pkg-1',
    userId: 'parent-1',
    participantType: 'child',
    childId: 'dep-child-1',
    status: 'active',
    startedAt: new Date(Date.now() - 86400000 * 10).toISOString(),
    createdAt: new Date(Date.now() - 86400000 * 12).toISOString(),
  },
  {
    id: 'csub-2',
    packageId: 'pkg-2',
    userId: 'student-1',
    participantType: 'self',
    status: 'completed',
    startedAt: new Date(Date.now() - 86400000 * 40).toISOString(),
    createdAt: new Date(Date.now() - 86400000 * 45).toISOString(),
  }
];

export const mockDocuments: import('@/types').PortfolioDocument[] = [
  {
    id: 'doc-1',
    studentId: 'user-2',
    title: 'قصتي القصيرة الأولى: البحث عن الضوء',
    content: 'في قرية صغيرة تحيط بها الجبال من كل جانب، كان هناك شاب يدعى مالك. كان مالك يحلم دائماً باكتشاف ما وراء هذه الجبال الشاهقة...',
    status: 'reviewed',
    instructorFeedback: 'بداية ممتازة يا مالك! أسلوبك في الوصف جذاب جداً. أنصحك بالعمل أكثر على الحوار بين الشخصيات لإضفاء مزيد من الحيوية على القصة.',
    updatedAt: '2023-10-20T10:00:00Z'
  },
  {
    id: 'doc-2',
    studentId: 'user-2',
    title: 'مقال: تأثير التكنولوجيا على الأدب',
    content: 'لا شك أن التكنولوجيا الحديثة قد أحدثت ثورة في كل مجالات الحياة، والأدب ليس استثناءً. فمع ظهور الكتب الإلكترونية...',
    status: 'submitted',
    updatedAt: '2023-10-22T14:30:00Z'
  },
  {
    id: 'doc-3',
    studentId: 'user-2',
    title: 'مسودة: رواية الخيال العلمي',
    content: 'في عام 2150، لم تعد الأرض كما نعرفها...',
    status: 'draft',
    updatedAt: '2023-10-25T09:15:00Z'
  }
];

export const mockInstructorPricingOptions: import('@/types').InstructorPricingOption[] = [
  {
    id: 'ipo-1',
    label: 'مبتدئ',
    basePricePerSession: 100,
    isActive: true
  },
  {
    id: 'ipo-2',
    label: 'متوسط',
    basePricePerSession: 150,
    isActive: true
  },
  {
    id: 'ipo-3',
    label: 'خبير',
    basePricePerSession: 200,
    isActive: true
  }
];

export const mockPricingFormulaSettings: import('@/types').PricingFormulaSettings[] = [
  {
    id: 'default',
    platformMultiplier: 1.2,
    fixedAdminFee: 50,
    updatedAt: '2023-10-01T10:00:00Z'
  }
];

export const mockInstructorCompensationProfiles: import('@/types').InstructorCompensationProfile[] = [
  {
    id: 'icp-1',
    instructorId: 'inst-1',
    billingModel: 'monthly',
    selectedPricingOptionId: 'ipo-2',
    monthlyMinimumHours: 60,
    approvalStatus: 'approved',
    createdAt: '2023-10-01T10:00:00Z',
    updatedAt: '2023-10-02T10:00:00Z'
  },
  {
    id: 'icp-2',
    instructorId: 'inst-2',
    billingModel: 'per_session',
    selectedPricingOptionId: 'ipo-3',
    monthlyMinimumHours: 0,
    approvalStatus: 'approved',
    createdAt: '2023-10-05T10:00:00Z',
    updatedAt: '2023-10-06T10:00:00Z'
  },
  {
    id: 'icp-3',
    instructorId: 'inst-pending',
    billingModel: 'per_session',
    selectedPricingOptionId: 'ipo-1',
    monthlyMinimumHours: 0,
    approvalStatus: 'proposed',
    createdAt: '2023-10-25T10:00:00Z',
    updatedAt: '2023-10-25T10:00:00Z'
  },
  {
    id: 'icp-4',
    instructorId: 'inst-training',
    billingModel: 'monthly',
    selectedPricingOptionId: 'ipo-1',
    monthlyMinimumHours: 60,
    approvalStatus: 'under_discussion',
    createdAt: '2023-10-26T10:00:00Z',
    updatedAt: '2023-10-27T10:00:00Z'
  }
];

export const mockInstructorCertifications: import('@/types').InstructorCertification[] = [
  {
    id: 'ic-1',
    instructorId: 'inst-1',
    trainingCompletedAt: '2023-09-15T10:00:00Z',
    examPassed: true,
    examScore: 95,
    certifiedAt: '2023-09-20T10:00:00Z'
  },
  {
    id: 'ic-2',
    instructorId: 'inst-2',
    trainingCompletedAt: '2023-09-18T10:00:00Z',
    examPassed: true,
    examScore: 92,
    certifiedAt: '2023-09-22T10:00:00Z'
  },
  {
    id: 'ic-3',
    instructorId: 'inst-pending',
    trainingCompletedAt: '2023-10-25T10:00:00Z',
    examPassed: false,
    examScore: 65
  },
  {
    id: 'ic-4',
    instructorId: 'inst-training',
    examPassed: false
  }
];
